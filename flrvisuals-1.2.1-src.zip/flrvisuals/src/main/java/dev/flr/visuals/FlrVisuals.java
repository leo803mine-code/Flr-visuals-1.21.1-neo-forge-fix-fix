package dev.flr.visuals;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.common.NeoForge;

@Mod(FlrVisuals.MOD_ID)
public class FlrVisuals {
    public static final String MOD_ID = "flrvisuals";

    public FlrVisuals(IEventBus modBus) {
        Config.load();

        modBus.addListener(RegisterKeyMappingsEvent.class, ClientEvents::registerKeys);
        modBus.addListener(EntityRenderersEvent.AddLayers.class, ClientEvents::addLayers);
        FlrSounds.register(modBus);

        NeoForge.EVENT_BUS.addListener(RenderGuiEvent.Post.class, ClientEvents::gui);
        NeoForge.EVENT_BUS.addListener(ViewportEvent.ComputeFogColor.class, ClientEvents::fogColor);
        NeoForge.EVENT_BUS.addListener(ViewportEvent.RenderFog.class, ClientEvents::fogRender);
        NeoForge.EVENT_BUS.addListener(GameEvents::tick);
    }
}

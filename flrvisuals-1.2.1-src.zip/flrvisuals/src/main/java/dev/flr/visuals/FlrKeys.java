package dev.flr.visuals;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

/** Key mappings for FLR Visuals. All of them can be changed in Options > Controls. */
public final class FlrKeys {
    public static final KeyMapping MENU = new KeyMapping(
            "key.flrvisuals.menu", InputConstants.Type.KEYSYM, 344, "key.categories.flrvisuals");
    public static final KeyMapping MASTER = new KeyMapping(
            "key.flrvisuals.master", InputConstants.Type.KEYSYM, InputConstants.UNKNOWN.getValue(),
            "key.categories.flrvisuals");
    /** Plays the custom track. Default is B. */
    public static final KeyMapping SOUND = new KeyMapping(
            "key.flrvisuals.sound", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, "key.categories.flrvisuals");

    private FlrKeys() {
    }
}

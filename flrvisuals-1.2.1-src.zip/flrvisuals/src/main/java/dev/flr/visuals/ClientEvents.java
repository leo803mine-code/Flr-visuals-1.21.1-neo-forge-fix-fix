package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.util.Mth;
import net.minecraft.world.level.material.FogType;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

/**
 * Client-side hooks for FLR Visuals: key mappings, player layers, HUD badge, fog.
 *
 * Full fog: when fogDensity is 1.0 the visible distance drops to about 10 blocks.
 * Density 0 leaves vanilla fog alone.
 */
public final class ClientEvents {
    private static int frames;
    private static long windowStart;

    /** Fog distance range at density 0 (far) and density 1 (full fog). */
    private static final float FAR_AT_MIN_DENSITY = 160f;
    private static final float FAR_AT_FULL_DENSITY = 10f;

    private ClientEvents() {
    }

    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(FlrKeys.MENU);
        event.register(FlrKeys.MASTER);
    }

    public static void addLayers(EntityRenderersEvent.AddLayers event) {
        for (PlayerSkin.Model skin : event.getSkins()) {
            EntityRenderer<?> renderer = event.getSkin(skin);
            if (renderer instanceof PlayerRenderer playerRenderer) {
                playerRenderer.addLayer(new CosmeticsLayer(playerRenderer));
            }
        }
    }

    public static void gui(RenderGuiEvent.Post event) {
        // custom track on key press (key is set in Controls)
        Minecraft track = Minecraft.getInstance();
        while (FlrKeys.SOUND.consumeClick()) {
            track.getSoundManager().play(SimpleSoundInstance.forUI(FlrSounds.TRACK, 1.0F));
        }

        // frames per second, updated once a second
        frames++;
        long now = System.nanoTime();
        if (now - windowStart >= 1_000_000_000L) {
            Config.fps = frames;
            frames = 0;
            windowStart = now;
        }

        Minecraft mc = Minecraft.getInstance();
        if (!Config.hud || mc.screen != null || mc.options.hideGui || !Config.master) return;

        int theme = Mth.clamp(Config.theme, 0, Config.THEME_NAMES.length - 1);
        String text = "FLR | " + Config.THEME_NAMES[theme] + " | " + Config.fps + " fps";
        GuiGraphics g = event.getGuiGraphics();
        g.drawString(mc.font, text, 4, 4, Config.color() | 0xFF000000, true);
    }

    public static void fogColor(ViewportEvent.ComputeFogColor event) {
        if (!Config.master || Config.fogTint <= 0) return;
        if (event.getCamera().getFluidInCamera() != FogType.NONE) return;

        int accent = Config.color();
        float t = (float) Config.fogTint * 0.6f;
        event.setRed(Mth.lerp(t, event.getRed(), ((accent >> 16) & 255) / 255f));
        event.setGreen(Mth.lerp(t, event.getGreen(), ((accent >> 8) & 255) / 255f));
        event.setBlue(Mth.lerp(t, event.getBlue(), (accent & 255) / 255f));
    }

    public static void fogRender(ViewportEvent.RenderFog event) {
        if (!Config.master || Config.fogDensity <= 0) return;
        if (event.getType() != FogType.NONE) return;

        float density = Mth.clamp((float) Config.fogDensity, 0f, 1f);
        float far = Mth.lerp(density, FAR_AT_MIN_DENSITY, FAR_AT_FULL_DENSITY);
        // near plane pulls in as the fog gets thicker; at full density fog starts right at the camera
        float near = far * 0.1f * (1f - density);

        event.setNearPlaneDistance(near);
        event.setFarPlaneDistance(far);
        event.setCanceled(true);
    }
}

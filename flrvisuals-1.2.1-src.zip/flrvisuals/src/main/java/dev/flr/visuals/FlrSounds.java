package dev.flr.visuals;

import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Custom sounds. Each sound needs a matching entry in assets/flrvisuals/sounds.json. */
public final class FlrSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, FlrVisuals.MOD_ID);

    public static final DeferredHolder<SoundEvent, SoundEvent> TRACK =
            SOUNDS.register("flr_track", SoundEvent::createVariableRangeEvent);

    private FlrSounds() {
    }

    public static void register(IEventBus modBus) {
        SOUNDS.register(modBus);
    }
}

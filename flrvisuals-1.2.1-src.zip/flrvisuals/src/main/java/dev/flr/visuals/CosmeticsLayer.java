package dev.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

/**
 * Procedural cosmetics for players: smooth membrane wings with feather veins,
 * a glow halo and a cape. No textures needed, so the shapes stay smooth at any size.
 *
 * Coordinates are in player model space: y is negative upward, +z is behind the player.
 */
public class CosmeticsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {

    /** Wing palettes by style index; index 0 follows the theme accent. */
    private static final int[] WING_PALETTE = {
            0,          // theme accent (filled at runtime)
            0xFFFF4D6D, // demon
            0xFF2B2D42, // dark
            0xFF8ECAE6, // crystal
            0xFF80FFDB  // energy
    };

    public CosmeticsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        if (!Config.master || player.isInvisible()) return;

        Minecraft mc = Minecraft.getInstance();
        boolean self = player == mc.player;
        if (!self) {
            if (!Config.others) return;
            if (mc.player != null
                    && player.distanceToSqr(mc.player) > Config.maxDistance * Config.maxDistance) return;
        }

        boolean perf = Config.autoPerf && !self;
        float size = (float) (Config.scale * Config.wingSize);
        float dy = player.isCrouching() ? 0.2f : 0f;
        int accent = Config.color() | 0xFF000000;

        Matrix4f m = pose.last().pose();
        VertexConsumer vc = buffers.getBuffer(RenderType.lightning());

        if (Config.cape) {
            cape(vc, m, ageInTicks, limbSwingAmount, dy, accent);
        }
        if (Config.halo) {
            halo(vc, m, ageInTicks, dy, accent, perf ? 18 : 36);
        }
        if (Config.wings) {
            int style = Mth.clamp(Config.wingStyle, 0, WING_PALETTE.length - 1);
            int base = style == 0 ? accent : WING_PALETTE[style];
            // style 0 is an angelic white tinted toward the theme accent
            int wingCol = style == 0 ? blend(0xFFFFFFFF, accent, 0.25f) : base;

            float phase = ageInTicks * 0.12f + limbSwing * 0.6f;
            float amp = 0.3f + 0.4f * limbSwingAmount + (player.onGround() ? 0f : 0.4f);
            float flap = Mth.clamp((float) Math.sin(phase) * amp, -1f, 1f);

            int feathers = perf ? 6 : 10;
            for (int side = -1; side <= 1; side += 2) {
                // soft outer glow first, then the membrane on top
                wing(vc, m, side, flap, feathers, size * 1.15f, dy, wingCol, true);
                wing(vc, m, side, flap, feathers, size, dy, wingCol, false);
            }
        }
    }

    // ---------- wings ----------

    /**
     * Angelic wing: feathers hang from an arm (root on the back, wrist further out and up),
     * each feather is a fading stroke from its base on the arm to its tip, and a translucent
     * membrane is stretched between the feathers. Glow pass is the same shape, larger and fainter.
     */
    private static void wing(VertexConsumer vc, Matrix4f m, int side, float flap, int feathers, float scale,
                             float dy, int color, boolean glowPass) {
        // arm: from the back between the shoulder blades out and up to the wrist
        float[] root = {side * 0.06f, -1.2f + dy, 0.16f};
        float[] wrist = {root[0] + side * 0.45f * scale, root[1] - 0.75f * scale, root[2] + 0.1f * scale};

        float[][] bases = new float[feathers][];
        float[][] tips = new float[feathers][];
        for (int i = 0; i < feathers; i++) {
            float t = i / (float) (feathers - 1);
            // feathers start along the arm, primaries near the wrist, secondaries near the body
            bases[i] = lerp3(root, wrist, 0.2f + 0.8f * t);
            // leading edge points up and out, trailing edge points out, down and back
            float ang = Mth.lerp(t, 1.1f, -0.5f) + flap * 0.3f * (1f - 0.5f * t);
            float len = scale * 0.85f * (0.55f + 0.45f * (float) Math.sin(Math.PI * (0.2 + 0.6 * t)));
            tips[i] = new float[] {
                    bases[i][0] + side * (float) Math.cos(ang) * len,
                    bases[i][1] - (float) Math.sin(ang) * len,
                    bases[i][2] + len * 0.4f * t
            };
        }

        // membrane between neighbouring feathers: translucent at the arm, fading to the outline
        int membraneBase = withA(color, glowPass ? 40 : 70);
        int membraneTip = withA(color, 0);
        for (int i = 0; i < feathers - 1; i++) {
            tri(vc, m, bases[i], tips[i], tips[i + 1], membraneBase, membraneTip, membraneTip);
            tri(vc, m, bases[i], tips[i + 1], bases[i + 1], membraneBase, membraneTip, membraneBase);
        }

        if (!glowPass) {
            // feather strokes: bright at the base, fading to the tip
            int featherBase = withA(blend(0xFFFFFFFF, color, 0.3f), 160);
            int featherTip = withA(color, 15);
            for (int i = 0; i < feathers; i++) {
                float[] b = bases[i];
                float[] w = {b[0], b[1] + 0.03f * scale, b[2]};
                tri(vc, m, b, w, tips[i], featherBase, featherBase, featherTip);
            }
        }
    }

    private static float[] lerp3(float[] p, float[] q, float t) {
        return new float[] {
                p[0] + (q[0] - p[0]) * t,
                p[1] + (q[1] - p[1]) * t,
                p[2] + (q[2] - p[2]) * t
        };
    }

    private static int blend(int a, int b, float t) {
        t = Mth.clamp(t, 0f, 1f);
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = Math.round(ar + (br - ar) * t);
        int g = Math.round(ag + (bg - ag) * t);
        int bl = Math.round(ab + (bb - ab) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ---------- halo ----------

    private static void halo(VertexConsumer vc, Matrix4f m, float ageInTicks, float dy, int color, int segments) {
        float y = -2.15f + dy;
        float inner = 0.26f;
        float outer = 0.34f;
        float spin = ageInTicks * 0.04f;
        int innerCol = withA(color, 220);
        int outerCol = withA(color, 30);
        for (int j = 0; j < segments; j++) {
            float a0 = (float) (Math.PI * 2 * j / segments) + spin;
            float a1 = (float) (Math.PI * 2 * (j + 1) / segments) + spin;
            float[] i0 = {(float) Math.cos(a0) * inner, y, (float) Math.sin(a0) * inner};
            float[] i1 = {(float) Math.cos(a1) * inner, y, (float) Math.sin(a1) * inner};
            float[] o0 = {(float) Math.cos(a0) * outer, y, (float) Math.sin(a0) * outer};
            float[] o1 = {(float) Math.cos(a1) * outer, y, (float) Math.sin(a1) * outer};
            tri(vc, m, i0, o0, o1, innerCol, outerCol, outerCol);
            tri(vc, m, i0, o1, i1, innerCol, outerCol, innerCol);
        }
    }

    // ---------- cape ----------

    private static void cape(VertexConsumer vc, Matrix4f m, float ageInTicks, float limbSwingAmount,
                             float dy, int color) {
        float sway = (float) Math.sin(ageInTicks * 0.1f) * 0.04f + limbSwingAmount * 0.08f;
        float topY = -1.4f + dy;
        float botY = -0.2f + dy;
        float z0 = 0.12f;
        float z1 = 0.28f + sway;
        float[] tl = {-0.25f, topY, z0};
        float[] tr = {0.25f, topY, z0};
        float[] bl = {-0.3f + sway, botY, z1};
        float[] br = {0.3f + sway, botY, z1};
        int top = withA(color, 230);
        int bottom = withA(color, 50);
        tri(vc, m, tl, tr, bl, top, top, bottom);
        tri(vc, m, tr, br, bl, top, bottom, bottom);
    }

    // ---------- helpers ----------

    private static int withA(int argb, int a) {
        return (Mth.clamp(a, 0, 255) << 24) | (argb & 0xFFFFFF);
    }

    /** Emits one triangle, twice (front and back) so it stays visible from both sides. */
    private static void tri(VertexConsumer vc, Matrix4f m, float[] a, float[] b, float[] c,
                            int ca, int cb, int cc) {
        vc.addVertex(m, a[0], a[1], a[2]).setColor(ca);
        vc.addVertex(m, b[0], b[1], b[2]).setColor(cb);
        vc.addVertex(m, c[0], c[1], c[2]).setColor(cc);
        vc.addVertex(m, c[0], c[1], c[2]).setColor(cc);
        vc.addVertex(m, b[0], b[1], b[2]).setColor(cb);
        vc.addVertex(m, a[0], a[1], a[2]).setColor(ca);
    }
}
